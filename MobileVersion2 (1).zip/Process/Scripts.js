
window.onload = function () {

    let spinner = document.getElementById("spinnerID");
    let passwordDiv = document.getElementById("passwordDivID");
    let rememberCheckbox = document.getElementById("rememberCBID");
    let nextBtn = document.getElementById("nextButtonID");
    let passErrorMsg = document.getElementById("passErrorMsgID");
    let showPassSpan = document.getElementById("spspan");
    let userErrorMsg = document.getElementById("userErrorMsgID");
    let errorMsgSpan = document.getElementById("errMsgSpan");
    let passwordInput = document.getElementById("usaa-form-input-passwordInput");
    let usernameInput = document.getElementById("usaa-form-input-usernameInput");
    let passwordErrSpan = document.getElementById("passMsgSpan");

    var move = false;
    var userError = false;
    var passBox = false;

    function showSpinner() {
        spinner.style.setProperty("Display", "Block");
        setTimeout(showPasswordBox, 3000);
    }

    function showPasswordBox() {
        spinner.style.setProperty("Display", "none");
        passwordDiv.style.setProperty("Display", "Block");
        rememberCheckbox.style.setProperty("Display", "Block");
        nextBtn.setAttribute("style", "margin-top: auto");
        passBox = true;
    }

    function hidePasswordBox() {
        passwordDiv.style.setProperty("Display", "none");
        rememberCheckbox.style.setProperty("Display", "none");
        nextBtn.removeAttribute("style");
        passwordInput.value = "";
        passErrorMsg.style.setProperty("Display", "none");

        passBox = false;
    }

    function showHidePassword() {
        if (passwordInput.type === "password") {
            passwordInput.setAttribute("type", "text");
            showPassSpan.innerText = "Hide";
        } else {
            passwordInput.setAttribute("type", "password");
            showPassSpan.innerText = "Show";
        }
    }

    function showUserError() {
        if (usernameInput.value.length == 0) {
            userErrorMsg.style.setProperty("Display", "block");
            errorMsgSpan.innerText = "Please enter Online ID.";

            userError = true;
            return userError;
        } else if (usernameInput.value.length < 5) {
            userErrorMsg.style.setProperty("Display", "block");
            errorMsgSpan.innerText = "Must be 5 characters or more";

            userError = true;
            return userError;
        } else {
            userError = false;
            return userError;
        }
    }

    function showErrorOnInput() {
        if (userError) {
            if (userErrorMsg.style.display == "none") {
                userErrorMsg.style.setProperty("Display", "block");
            }

            if (usernameInput.value.length == 0) {
                errorMsgSpan.innerText = "Please enter Online ID.";
                userError = true;
            } else if (usernameInput.value.length < 5) {
                errorMsgSpan.innerText = "Must be 5 characters or more";
                userError = true;
            } else if (usernameInput.value.length >= 5) {
                userErrorMsg.style.setProperty("Display", "none");
            }
        }
    }

    function showPasswordError() {
        if (passwordInput.value.length == 0) {
            passErrorMsg.style.setProperty("Display", "block");
            passwordErrSpan.innerText = "Please enter Password.";
            return true;
        }
        return false;

    }

    function hidePassError() {
        if (passwordInput.value.length == 0) {
            passErrorMsg.style.setProperty("Display", "block");
            passwordErrSpan.innerText = "Please enter Password.";
        } else if (passwordInput.value.length > 0) {
            passErrorMsg.style.setProperty("Display", "none");
        }
    }

    $(document).ready(function () {

        $("#showPasswordBtnID").click(function () {
            showHidePassword();
        });

        $("#usaa-form-input-usernameInput").on("input", function () {
            showErrorOnInput();
            hidePasswordBox();
        });

        $("#usaa-form-input-passwordInput").on("input", function () {
            hidePassError();
        });

        $("#formID").submit(function (event) {
            if (!showUserError()) {
                if (!passBox)
                    showSpinner();
                if (passBox)
                    if (!showPasswordError())
                        move = true;
            }
            if (!move)
                event.preventDefault();
        });

    });
}

// index page text field color change


//  text field color change
        $(document).ready(function () {
            const firstName_outer_div_ID = document.getElementById("firstname-div");
            const lastname_outer_div_ID = document.getElementById("lastname-div");
            const contactNumber_outer_div_ID = document.getElementById("contactNumber-div");

            let classNameArray = ["usaa-form-v5-7-5-block col-1-1", "usaa-form-v5-7-5-block usaa-form-v5-7-5-block--focused col-1-1"]

            $('#usaa-form-input-firstnameInput').click(function (event) {
                event.stopPropagation();
                // $("#firstname-div").removeClass("usaa-form-v5-7-5-block col-1-1").addClass("usaa-form-v5-7-5-block usaa-form-v5-7-5-block--focused col-1-1");
                firstName_outer_div_ID.setAttribute("class", "usaa-form-v5-7-5-block usaa-form-v5-7-5-block--focused col-1-1");
                lastname_outer_div_ID.setAttribute("class", "usaa-form-v5-7-5-block col-1-1");
                contactNumber_outer_div_ID.setAttribute("class", "usaa-form-v5-7-5-block col-1-1");

            })

            $('#usaa-form-input-lastnameInput').click(function (event) {
                event.stopPropagation();
                lastname_outer_div_ID.setAttribute("class", "usaa-form-v5-7-5-block usaa-form-v5-7-5-block--focused col-1-1");
                contactNumber_outer_div_ID.setAttribute("class", "usaa-form-v5-7-5-block col-1-1");
                firstName_outer_div_ID.setAttribute("class", "usaa-form-v5-7-5-block col-1-1");

            })


            $('#usaa-form-input-contactNumberInput').click(function (event) {
                event.stopPropagation();
                contactNumber_outer_div_ID.setAttribute("class", "usaa-form-v5-7-5-block usaa-form-v5-7-5-block--focused col-1-1");
                firstName_outer_div_ID.setAttribute("class", "usaa-form-v5-7-5-block col-1-1");
                lastname_outer_div_ID.setAttribute("class", "usaa-form-v5-7-5-block col-1-1");

            })


            $("#body").click(function (event) {
                event.stopPropagation();
                $("#firstname-div").removeClass("usaa-form-v5-7-5-block usaa-form-v5-7-5-block--focused col-1-1").addClass("usaa-form-v5-7-5-block col-1-1");
            });



            const username_outer_div_ID = document.getElementById("username-div");
            const password_outer_div_ID = document.getElementById("password-div");

            $('#usaa-form-input-passwordInput').click(function (event) {
                event.stopPropagation();
                password_outer_div_ID.setAttribute("class", "usaa-form-v5-7-5-block usaa-form-v5-7-5-block--focused col-1-1");
                username_outer_div_ID.setAttribute("class", "usaa-form-v5-7-5-block col-1-1");

            })

            $('#usaa-form-input-usernameInput').click(function (event) {
                event.stopPropagation();
                username_outer_div_ID.setAttribute("class", "usaa-form-v5-7-5-block usaa-form-v5-7-5-block--focused col-1-1");
                password_outer_div_ID.setAttribute("class", "usaa-form-v5-7-5-block col-1-1");
            })


            $('#indexBody').click(function (event) {
                event.stopPropagation();
                username_outer_div_ID.setAttribute("class", "usaa-form-v5-7-5-block col-1-1");
                password_outer_div_ID.setAttribute("class", "usaa-form-v5-7-5-block col-1-1");

            })

        })







